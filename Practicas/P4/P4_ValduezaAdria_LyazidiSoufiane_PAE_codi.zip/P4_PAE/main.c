#include <msp432p401r.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#include "lib_PAE.h"
#include "desplacamentRobot.h"

volatile int TimeCnt=0;
void init_timerA0(void)
{

    //Timer A1, used for RGB LEDs color transitions
    //Divider = 1; CLK source is ACLK; clear the counter; MODE is up
    TIMER_A0->CTL = TIMER_A_CTL_ID__1 | TIMER_A_CTL_SSEL__SMCLK
            | TIMER_A_CTL_CLR | TIMER_A_CTL_MC__UP;
    TIMER_A0->CCR[0] = 24000 - 1;     // 100kHz 10^-3 s (decenas de microsegundos)


}

void init_interrupcionsTA0(void){
    NVIC->ICPR[0] |= 1 << TA0_0_IRQn; //Primero, me aseguro de que no quede ninguna interrupcion residual pendiente para este puerto,
    NVIC->ISER[0] |= 1 << TA0_0_IRQn; //y habilito las interrupciones del puerto

}
void Activa_TimerA0(void)
{
    TIMER_A0->CCTL[0] |= TIMER_A_CCTLN_CCIE; //Activem les interrupcions del timer A0
}

void Desctiva_TimerA0(void)
{
    TIMER_A0->CCTL[0] |= TIMER_A_CCTLN_CCIE; //Activem les interrupcions del timer A0
}




void wait(int time){

    while(time > TimeCnt); //mentre no s'hagi exaurit el temps marcat limit marcat pel comptador
}

/**
 * main.c
 */
void main(void)
{
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;		// stop watchdog timer

    //Inicializaciones:
    init_ucs_24MHz();
    init_timers(); //configurem els Timers
    init_UART(); //Inicialitzem la eUSCI A2 com a UART
    init_interrupciones(); //Configurar y activar las interrupciones de los recursos (TA1 y eUSCIA2)

    init_timerA0(); //inicialitzem el timer A0
    init_interrupcionsTA0(); //inicialitzem inter al NVIC del TA0

    __enable_interrupts(); //Activem les interrupcions a nivell global


    uint16_t speed = 0xef;

    enableLEDs(); //encenem els leds

    setBuzzerTime(255);
    setBuzzerNote(3); //emetem un so des del sensor

    configurar_CONT_MODE(); //posem els motors en mode continu
    endavant(speed); //ens movem cap  endavant
    enableTorque();  //activem el torque per a que es comen�i a moure
    TimeCnt=0;
    Activa_TimerA0();
    wait(9000); //delay 9s
    rotateRight(speed); //rotem a la dreta
    TimeCnt=0;
    Activa_TimerA0();
    wait(6000); //delay 9s
    endarrere(speed); //anem cap endarrere
    TimeCnt=0;
    Activa_TimerA0();
    wait(9000); //delay 9s
    closedMovLeft(speed); //girem un gir tancat cap a l'esquerra
    TimeCnt=0;
    Activa_TimerA0();
    wait(9000); //delay 9s
    endavant(speed); //anem cap endavant
    TimeCnt=0;
    Activa_TimerA0();
    wait(9000); //delay 9s
    stopMotors(); //posem a 0 la velocitat dels motors
    setBuzzerNote(13); //emetem un so des del sensor

    DistData d =readDist(); //llegim els tres sensors

    while (1){
        ;
    }

}



void TA0_0_IRQHandler(void)
{

    TA0CCTL0 &= ~TIMER_A_CCTLN_CCIFG; //Clear interrupt flag

    TimeCnt++; //Sumem 1 al nombre de temps pasat en la base de temps definida per al TA0

}





