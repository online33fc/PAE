/*
 * desplacamentRobot.h
 *
 *  Created on: 23 abr. 2023
 *      Author: Soufiane
 */

#ifndef DESPLACAMENTROBOT_H_
#define DESPLACAMENTROBOT_H_


#include <msp432p401r.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#include "lib_PAE.h"


typedef uint8_t byte;
#define TXD0_READY (UCA0IFG & UCTXIFG)

#define bLenInx 3
#define TXD2_READY (UCA2IFG & UCTXIFG)
#define UC0_BUS (UCA0STATW & UCBUSY)
#define UC2_BUS (UCA2STATW & UCBUSY)


#define READ_DATA 0x02
#define WRITE_DATA 0x03
#define MOTOR_DRET 0x02
#define MOTOR_ESQ 0x03
#define SENSOR 100

typedef struct
{
    byte StatusPacket[16]; //el status packet rebut del modul corresponent
    byte TimeOut;    //Indica si ha saltat el timeout i no s'ha acabat de llegir el status packet
    byte StatusCheckSum; //Indica si el checksum rebut es correcte

} RxReturn;

typedef struct
{
    byte center;
    byte right;
    byte left;

} DistData;




void init_interrupciones(void);

void init_timers(void);

/* funcions per canviar el sentit de les comunicacions */
void Sentit_Dades_Rx(void);

void Sentit_Dades_Tx(void);

void config_DIRECTION_PORT(void);

void init_UART(void);

void init_UART_emulador(void);

/* funci� TxUACx(byte): envia un byte de dades per la UART 0 */
void TxUACx(byte bTxdData);

//TxPacket() 3 par�metres: ID del Dynamixel, Mida dels par�metres, Instruction byte. torna la mida del "Return packet"
byte TxPacket(byte bID, byte bParameterLength, byte bInstruction, byte Parametros[16]);

void Activa_TimerA1_TimeOut(void);

void Desctiva_TimerA1_TimeOut(void);

void Reset_Timeout(void);

byte TimeOut(int TimeOut);

void enable_UART2_Intr(void);

void disable_UART2_Intr(void);



void set_RX_Byte_Recived(void);

byte get_RX_Byte_Recived(void);

void set_RX_Byte_Not_Recived(void);

byte get_read_byte_UART(void);

RxReturn RxPacket(void);

void EUSCIA2_IRQHandler(void);

void EUSCIA0_IRQHandler(void);

//Movments

RxReturn sendReciPacket(byte bID, byte bParameterLength, byte bInstruction, byte Parametros[16]);

void enableLEDs(void);
void disableLEDs(void);

void configurar_CONT_MODE(void);

void enableTorque(void);
void disableTorque(void);

void setMotorSpeedDir(uint16_t speed, byte bID, byte bDir);

void move(uint16_t speed1, uint16_t speed2,  byte bID1, byte bDir1, byte bID2, byte bDir2);

void endavant(uint16_t speed);

void endarrere(uint16_t speed);

void movRight(uint16_t speedMain, uint16_t speed);

void movLeft(uint16_t speedMain, uint16_t speed);

void closedMovRight(uint16_t speed);

void closedMovLeft(uint16_t speed);

void rotateRight(uint16_t speed);

void rotateLeft(uint16_t speed);

DistData readDist(void);

byte newSoundDetected(void); //returns 1 if true 0 if false

void enableMovIfSound(void);

void setBuzzerTime(byte time);

void setBuzzerNote(byte note);

void delay_t(uint32_t temps);

void TA1_0_IRQHandler(void);

void stopMotors(void);



#endif /* DESPLACAMENTROBOT_H_ */
