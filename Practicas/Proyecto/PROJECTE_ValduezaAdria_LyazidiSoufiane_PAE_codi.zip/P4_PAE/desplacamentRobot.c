/*
 * desplacamentRobot.c
 *
 *  Created on: 23 abr. 2023
 *      Author: Soufiane
 */

#include "desplacamentRobot.h"

volatile int TimeOutCnt; //variable que ens servira per comptar el nombre de cicles temps
volatile int TimeCnt = 0;
volatile byte byte_Recibido = 0;
volatile byte DatoLeido_UART = 0;

void init_interrupciones()
{
    // Configuracion al estilo MSP430 "clasico":
    // --> Enable Port 4 interrupt on the NVIC.
    // Segun el Datasheet (Tabla "6-39. NVIC Interrupts", apartado "6.7.2 Device-Level User Interrupts"),
    // la interrupcion del puerto 1 es la User ISR numero 35.
    // Segun el Technical Reference Manual, apartado "2.4.3 NVIC Registers",
    // hay 2 registros de habilitacion ISER0 y ISER1, cada uno para 32 interrupciones (0..31, y 32..63, resp.),
    // accesibles mediante la estructura NVIC->ISER[x], con x = 0 o x = 1.
    // Asimismo, hay 2 registros para deshabilitarlas: ICERx, y dos registros para limpiarlas: ICPRx.

    //Int. TA0 de CCTL0, corresponde al bit 10 del primer registro ISER0
    NVIC->ICPR[0] |= 1 << TA1_0_IRQn; //Primero, me aseguro de que no quede ninguna interrupcion residual pendiente para este puerto,
    NVIC->ISER[0] |= 1 << TA1_0_IRQn; //y habilito las interrupciones del puerto

    NVIC->ICPR[0] |= 1 << EUSCIA2_IRQn; //Primero, me aseguro de que no quede ninguna interrupcion residual pendiente para este puerto,
    NVIC->ISER[0] |= 1 << EUSCIA2_IRQn; //y habilito las interrupciones del puerto

    NVIC->ICPR[0] |= 1 << TA0_0_IRQn; //Primero, me aseguro de que no quede ninguna interrupcion residual pendiente para este puerto,
    NVIC->ISER[0] |= 1 << TA0_0_IRQn; //y habilito las interrupciones del puerto

}

/**************************************************************************
 * INICIALIZACION DELS TIMERS
 *
 * Sin datos de entrada
 *
 * Sin datos de salida
 *
 **************************************************************************/
void init_timers(void)
{

    //Timer A1, used for RGB LEDs color transitions
    //Divider = 1; CLK source is ACLK; clear the counter; MODE is up
    TIMER_A1->CTL = TIMER_A_CTL_ID__1 | TIMER_A_CTL_SSEL__SMCLK
            | TIMER_A_CTL_CLR | TIMER_A_CTL_MC__UP;
    TIMER_A1->CCR[0] = 240 - 1;     // 100kHz 10^-5 s (decenas de microsegundos)

    //Timer A1, used for RGB LEDs color transitions
    //Divider = 1; CLK source is ACLK; clear the counter; MODE is up
    TIMER_A0->CTL = TIMER_A_CTL_ID__1 | TIMER_A_CTL_SSEL__SMCLK
            | TIMER_A_CTL_CLR | TIMER_A_CTL_MC__UP;
    TIMER_A0->CCR[0] = 24000 - 1;   // 1kHz 10^-3 s (microsegundos)
}

void Activa_TimerA0(void)
{
    TIMER_A0->CCTL[0] |= TIMER_A_CCTLN_CCIE; //Activem les interrupcions del timer A0
    TimeCnt = 0;
}

void Desactiva_TimerA0(void)
{
    TIMER_A0->CCTL[0] &= ~TIMER_A_CCTLN_CCIE; //Activem les interrupcions del timer A0
}

void wait(int time)
{

    while (time > TimeCnt)
        ;

}

int TimeOutTA0(int time)
{

    if (time > TimeCnt)
        return 0;
    else
        return 1;

}

void TA0_0_IRQHandler(void)
{

    TA0CCTL0 &= ~TIMER_A_CCTLN_CCIFG; //Clear interrupt flag

    TimeCnt++; //Sumem 1 al nombre de temps pasat en la base de temps definida per al TA0

}

/* funcions per canviar el sentit de les comunicacions */
void Sentit_Dades_Rx(void)
{ //Configuraci� del Half Duplex dels motors: Recepci�
    P3OUT &= ~BIT0; //El pin P3.0 (DIRECTION_PORT) el posem a 0 (Rx)
}
void Sentit_Dades_Tx(void)
{ //Configuraci� del Half Duplex dels motors: Transmissi�
    P3OUT |= BIT0; //El pin P3.0 (DIRECTION_PORT) el posem a 1 (Tx)
}

void config_DIRECTION_PORT(void)
{

    //El Pin 0 del port 3 es l'encarregat de indicar la direcci� de data 1 per TX 0 per RX
    P3SEL0 &= ~BIT0; //P3.0 es GPIO
    P3SEL1 &= ~BIT0; //P3.0 es GPIO

    P3DIR |= BIT0; //Es de sortida per escriure la direcci� de data

    Sentit_Dades_Rx(); //Per defecte estem en recepci�

}

void init_UART(void)
{
    UCA2CTLW0 |= UCSWRST; //Fem un reset de la USCI, desactiva la USCI
    UCA2CTLW0 |= UCSSEL__SMCLK; //UCSYNC=0 mode as�ncron
                                //UCMODEx=0 seleccionem mode UART
                                //UCSPB=0 nomes 1 stop bit
                                //UC7BIT=0 8 bits de dades
                                //UCMSB=0 bit de menys pes primer
                                //UCPAR=x ja que no es fa servir bit de paritat
                                //UCPEN=0 sense bit de paritat
                                //Triem SMCLK (24MHz) com a font del clock BRCLK
    UCA2MCTLW = UCOS16; // Necessitem sobre-mostreig => bit 0 = UCOS16 = 1
    UCA2BRW = 3;  //Prescaler de BRCLK fixat a 3. Com SMCLK va a 24MHz,
                  //volem un baud rate de 500kb/s i fem sobre-mostreig de 16
                  //el rellotge de la UART ha de ser de 8MHz (24MHz/3).
                  //Per tant no hi ha part fraccionaria del baud rate
    //Configurem els pins de la UART
    P3SEL0 |= (BIT2 | BIT3 ); //I/O funci�: P3.3 = UART2TX, P3.2 = UART2RX
    P3SEL1 &= ~(BIT2 | BIT3 );
    UCA2CTLW0 &= ~UCSWRST; //Reactivem la l�nia de comunicacions s�rie
    EUSCI_A2->IFG &= ~EUSCI_A_IFG_RXIFG; // Clear eUSCI RX interrupt flag
    EUSCI_A2->IE |= EUSCI_A_IE_RXIE; // Enable USCI_A2 RX interrupt, nomes quan tinguem la recepcio
    config_DIRECTION_PORT(); //configurem el port de direccio de data
}

void init_UART_emulador(void)
{
    UCA0CTLW0 |= UCSWRST; //Fem un reset de la USCI, desactiva la USCI
    UCA0CTLW0 |= UCSSEL__SMCLK; //UCSYNC=0 mode as�ncron
                                //UCMODEx=0 seleccionem mode UART
                                //UCSPB=0 nomes 1 stop bit
                                //UC7BIT=0 8 bits de dades
                                //UCMSB=0 bit de menys pes primer
                                //UCPAR=x ja que no es fa servir bit de paritat
                                //UCPEN=0 sense bit de paritat
                                //Triem SMCLK (24MHz) com a font del clock BRCLK
    UCA0MCTLW = UCOS16; // Necessitem sobre-mostreig => bit 0 = UCOS16 = 1
    UCA0BRW = 13; //Prescaler de BRCLK fixat a 13. Com SMCLK va a24MHz,
                  //volem un baud rate de 115200b/s i fem sobre-mostreig de 16
                  //el rellotge de la UART ha de ser de ~1.84Hz (24MHz/13).
    UCA0MCTLW |= (0x25 << 8); //UCBRSx, part fractional del baud rate
    //Configurem els pins de la UART
    P1SEL0 |= (BIT2 | BIT3 ); //I/O funci�: P3.3 = UART2TX, P3.2 = UART2RX
    P1SEL1 &= ~(BIT2 | BIT3 );
    UCA0CTLW0 &= ~UCSWRST; //Reactivem la l�nia de comunicacions s�rie
    EUSCI_A0->IFG &= ~EUSCI_A_IFG_RXIFG; // Clear eUSCI RX interrupt flag
    EUSCI_A0->IE |= EUSCI_A_IE_RXIE; // Enable USCI_A2 RX interrupt, nomes quan tinguem la recepcio
    config_DIRECTION_PORT(); //configurem el port de direccio de data
}

/* funci� TxUACx(byte): envia un byte de dades per la UART 0 */
void TxUACx(byte bTxdData)
{
    while (!TXD2_READY)
        ; // Espera a que estigui preparat el buffer de transmissi�
    UCA2TXBUF = bTxdData; //escrivim el byte a ser enviat

}

//TxPacket() 3 par�metres: ID del Dynamixel, Mida dels par�metres, Instruction byte. torna la mida del "Return packet"
byte TxPacket(byte bID, byte bParameterLength, byte bInstruction,
              byte Parametros[16])
{
    byte bCount, bCheckSum, bPacketLength;
    byte TxBuffer[32];
    Sentit_Dades_Tx(); //El pin P3.0 (DIRECTION_PORT) el posem a 1 (Transmetre)
    TxBuffer[0] = 0xff; //Primers 2 bytes que indiquen inici de trama FF, FF.
    TxBuffer[1] = 0xff;
    TxBuffer[2] = bID; //ID del m�dul al que volem enviar el missatge
    TxBuffer[3] = bParameterLength + 2; //Length(Parameter,Instruction,Checksum)
    TxBuffer[4] = bInstruction; //Instrucci� que enviem al M�dul

    //Comrpovem que no s'intenta escriure en les primeres posicions

    if ((Parametros[0] < 6) && (bInstruction == 3))
    { //si se intenta escribir en una direccion <= 0x05,
      //emitir mensaje de error de direccion prohibida:

        //y salir de la funcion sin mas:
        return 0;
    }

    for (bCount = 0; bCount < bParameterLength; bCount++) //Comencem a generar la trama que hem d�enviar
    {
        TxBuffer[bCount + 5] = Parametros[bCount];
    }
    bCheckSum = 0;
    bPacketLength = bParameterLength + 4 + 2;
    for (bCount = 2; bCount < bPacketLength - 1; bCount++) //C�lcul del checksum
    {
        bCheckSum += TxBuffer[bCount];
    }
    TxBuffer[bCount] = ~bCheckSum; //Escriu el Checksum (complement a 1)
    for (bCount = 0; bCount < bPacketLength; bCount++) //Aquest bucle �s el que envia la trama al M�dul Robot
    {
        TxUACx(TxBuffer[bCount]);
    }
    while ((UCA2STATW & UCBUSY))
        ; //Espera fins que s�ha transm�s el �ltim byte

    Sentit_Dades_Rx(); //Posem la l�nia de dades en Rx perqu� el m�dul Dynamixel envia resposta
    return (bPacketLength); //retornem la llargada de la trama
}

void Activa_TimerA1_TimeOut(void)
{
    TIMER_A1->CCTL[0] |= TIMER_A_CCTLN_CCIE; //Activem les interrupcions del timer A1
}

void Desctiva_TimerA1_TimeOut(void)
{
    TIMER_A1->CCTL[0] &= ~TIMER_A_CCTLN_CCIE; //Desactivem les interrupcions del timer A1
}

void Reset_Timeout(void)
{
    TimeOutCnt = 0; //resetejem el comptador de cicles de temps
}

byte TimeOut(int TimeOut)
{
    //retornem 1 si s'ha sobrepassat el temps pasat per parametre en la base de temps de TA1 i 0 en cas contrari
    if (TimeOutCnt > TimeOut)
    {
        return 1;
    }
    else
    {
        return 0;
    }

}

void enable_UART2_Intr(void)
{
    UCA2IE |= UCRXIE; //activem les interupcions en la eUSCIA2
}

void disable_UART2_Intr(void)
{
    UCA2IE &= ~UCRXIE; //activem les interrupcions en la eUSCIA2
}

void set_RX_Byte_Recived(void)
{
    byte_Recibido = 1; //s'ha rebut el byte
}

byte get_RX_Byte_Recived(void)
{
    return byte_Recibido; //retornem el byte rebut
}

void set_RX_Byte_Not_Recived(void)
{
    byte_Recibido = 0; //no s'ha rebut el byte
}

byte get_read_byte_UART(void)
{
    return DatoLeido_UART; //retornem el byte llegit en la �ltima interrupci� de la eUSCI
}

RxReturn RxPacket(void)
{
    //see if activate aqui el return packet
    RxReturn respuesta;
    byte bCount, bLength, bCheckSum;
    byte Rx_time_out = 0;
    respuesta.TimeOut = Rx_time_out;
    Sentit_Dades_Rx(); //Ponemos la linea half duplex en Rx
    Activa_TimerA1_TimeOut(); //activem les interrupcions al timer TA1
    //Llegim els 4 primers bytes del status packet
    for (bCount = 0; bCount < 4; bCount++)
    {
        Reset_Timeout(); //resetejem el timer
        set_RX_Byte_Not_Recived(); //Posem per defecte que encara no s'ha rebut el byte
        while (!get_RX_Byte_Recived()) //Mentre no s'ha rebut cap byte
        {
            Rx_time_out = TimeOut(10000); // tiempo en decenas de microsegundos
            if (Rx_time_out) //si salta el timeout sortim del bucle
                break; //sale del while
        }
        if (Rx_time_out) //posem timeOut=1 a la resposta per indicar que no s'ha complert la lectura del status packet
        {
            respuesta.TimeOut = 1;
            break; //sale del for si ha habido Timeout
        }

        //Si no, es que todo ha ido bien, y leemos un dato:
        respuesta.StatusPacket[bCount] = get_read_byte_UART(); //Posem a la repsosta el byte rebut per la eUSCI
    } //fin del for
      // Continua llegint la resta de bytes del Status Packet si no ha saltat el time out
    if (!Rx_time_out)
    {
        //Llegim els bytes que queden un cop ja sabem la llargaria de al resta de la trama
        bLength = respuesta.StatusPacket[bLenInx] + 4;
        for (bCount = 4; bCount < bLength; bCount++)
        {
            Reset_Timeout();  //resetejem el timer
            set_RX_Byte_Not_Recived(); //Posem per defecte que encara no s'ha rebut el byte
            while (!get_RX_Byte_Recived()) //Mentre no s'ha rebut cap byte
            {
                Rx_time_out = TimeOut(1000); // tiempo en decenas de microsegundos
                if (Rx_time_out)  //si salta el timeout sortim del bucle
                {

                    //enviem un error de timeout
                    break;//sale del while
                }

            }
            if (Rx_time_out) //posem timeOut=1 a la resposta per indicar que no s'ha complert la lectura del status packet
            {
                respuesta.TimeOut = 1;
                break; //sale del for si ha habido Timeout
            }

            //Si no, es que todo ha ido bien, y leemos un dato:
            respuesta.StatusPacket[bCount] = get_read_byte_UART(); //Posem a la repsosta el byte rebut per la eUSCI
        } //f� del �ltim for
    }

    bCheckSum = 0;
    //Realitzem la comprovacio del checkSum
    if (!Rx_time_out)
    {
        for (bCount = 2; bCount < bLength - 1; bCount++)
        {
            bCheckSum += respuesta.StatusPacket[bCount];
        }
        bCheckSum = ~bCheckSum;
        if (bCheckSum != respuesta.StatusPacket[bLength - 1])
        {
            respuesta.StatusCheckSum = 1;
            //enviem un error de error en el checksum
        }
        else
        {
            respuesta.StatusCheckSum = 0; //checksum correcte
        }
    }
    return respuesta;
}

void EUSCIA2_IRQHandler(void)
{ //interrupcion de recepcion en la UART A2
    EUSCI_A2->IFG &= ~ EUSCI_A_IFG_RXIFG; // Clear interrupt
    UCA2IE &= ~UCRXIE; //Interrupciones desactivadas en RX
    DatoLeido_UART = UCA2RXBUF; //Llegim el byte enviat pel modul corresponent
    set_RX_Byte_Recived(); //Imformem que s'ha rebut un byte per que RXPacket ho pugui llegir
    UCA2IE |= UCRXIE; //Interrupciones reactivadas en RX
}

void EUSCIA0_IRQHandler(void)
{ //interrupcion de recepcion en la UART A0
    EUSCI_A0->IFG &= ~ EUSCI_A_IFG_RXIFG; // Clear interrupt
    UCA0IE &= ~UCRXIE; //Interrupciones desactivadas en RX
    DatoLeido_UART = UCA0RXBUF; //Llegim el byte enviat pel modul corresponent
    set_RX_Byte_Recived(); //
    UCA0IE |= UCRXIE; //Interrupciones reactivadas en RX
}

//Movments

RxReturn sendReciPacket(byte bID, byte bParameterLength, byte bInstruction,
                        byte Parametros[16])
{
    RxReturn ret;
    byte error_byte;
    byte time_out;
    byte checkSum;

    do //mentre hagi un error en el statuspacket o no s'hagi rebut del tot el status packet tornar a enviar la trama
    {
        TxPacket(bID, bParameterLength, bInstruction, Parametros); //enviem la trama per definir la velocitat i sentit
        ret = RxPacket(); //rebem el status packet
        error_byte = ret.StatusPacket[4]; // recollim el byte d'error
        time_out = ret.TimeOut; //recollim el bit de timeout
        checkSum = ret.StatusCheckSum;
    }
    while (time_out || error_byte || checkSum );
    return ret;
}

void enableLED(byte id)
{
    byte bID = id; //Pel motor dret
    byte bParameterLength = 2; //l'adre�a del LED i el nou valor
    byte bInstruction = WRITE_DATA; //escrivim a l'adre�a passada
    byte Parametros[16];
    Parametros[0] = 0x19; //l'adre�a del LED
    Parametros[1] = 0x01; //1 per que s'encengui

    sendReciPacket(bID, bParameterLength, bInstruction, Parametros); //cridem a la funcio que envia la trama i rep el status
}

void enableLED_R(void)
{
    enableLED(MOTOR_DRET);
}

void enableLED_L(void)
{
    enableLED(MOTOR_ESQ);
}

void disableLED(byte id)
{
    byte bID = id; //Pel motor dret
    byte bParameterLength = 2; //l'adre�a del LED i el nou valor
    byte bInstruction = WRITE_DATA; //escrivim a l'adre�a passada
    byte Parametros[16];
    Parametros[0] = 0x19; //l'adre�a del LED
    Parametros[1] = 0x00; //1 per que s'apagui

    sendReciPacket(bID, bParameterLength, bInstruction, Parametros); //cridem a la funcio que envia la trama i rep el status
}

void disableLED_R(void)
{
    disableLED(MOTOR_DRET);
}

void disableLED_L(void)
{
    disableLED(MOTOR_ESQ);
}

void enableLEDs(void)
{
    enableLED_R();
    enableLED_L();
}

void disableLEDs(void)
{
    disableLED_R();
    disableLED_L();
}

void configurar_CONT_MODE_Motor(byte id){
    byte bID = id; //Pel motor corresponent al id
    byte bParameterLength = 5; //l'adre�a del CW angle limit L i els valors del CW angle limit i CCW angle limit
    byte bInstruction = WRITE_DATA; //escrivim a l'adre�a passada
    byte Parametros[16];

    Parametros[0] = 0x06; //adre�em CW angle limit L per variar els 4 registres alhora
    Parametros[1] = 0x00; //posem a 0 CW angle limit L
    Parametros[2] = 0x00; //posem a 0 CW angle limit H
    Parametros[3] = 0x00; //posem a 0 CCW angle limit L
    Parametros[4] = 0x00; //posem a 0 CCW angle limit H

    sendReciPacket(bID, bParameterLength, bInstruction, Parametros); //cridem a la funcio que envia la trama i rep el status
}


void configurar_CONT_MODE(void)
{
    configurar_CONT_MODE_Motor(MOTOR_DRET);
    configurar_CONT_MODE_Motor(MOTOR_ESQ);

}

void enableTorqueMotor(byte id){
    byte bID = id; //posem l'id del motor pasat per parametre
    byte bParameterLength = 2; //l'adre�a del Torque i el nou valor
    byte bInstruction = WRITE_DATA; //escrivim a l'adre�a passada
    byte Parametros[16];

    Parametros[0] = 0x18; //l'adre�a del Torque
    Parametros[1] = 0x01; //1 per que s'habiliti

    sendReciPacket(bID, bParameterLength, bInstruction, Parametros); //cridem a la funcio que envia la trama i rep el status
}

void disableTorqueMotor(byte id){
    byte bID = id; //Pel motor corresponent
    byte bParameterLength = 2; //l'adre�a del Torque i el nou valor
    byte bInstruction = WRITE_DATA; //escrivim a l'adre�a passada
    byte Parametros[16];

    Parametros[0] = 0x18; //l'adre�a del Torque
    Parametros[1] = 0x00; //0 per que es deshabiliti

    sendReciPacket(bID, bParameterLength, bInstruction, Parametros); //cridem a la funcio que envia la trama i rep el status
}



void enableTorque(void)
{

    enableTorqueMotor(MOTOR_DRET);
    enableTorqueMotor(MOTOR_ESQ);

}

void disableTorque(void)
{

    disableTorqueMotor(MOTOR_DRET);
    disableTorqueMotor(MOTOR_ESQ);
}

void setMotorSpeedDir(uint16_t speed, byte bID, byte bDir)
{

    byte wheel_dir;

    byte bParameterLength = 3; //L'adre�a de la velocitat a la RAM i la part L i H de la vel.
    byte bInstruction = WRITE_DATA;  //WRITE DATA
    byte Parametros[16];

    wheel_dir = (bDir << 2); //despla�em la direccio 2 bits perque ha de ser el 10e bit, que correspon al 3er de la part H
    Parametros[0] = 0x20; //Les adre�em de memoria per variar la velocitat son 0x20-0x21
    Parametros[1] = (0xFF & speed); //Prenem la part L de la velocitat
    Parametros[2] = (wheel_dir | ((speed >> 8) & 0x03)); //agafem la part H de la velocitat tallan al 2on bit (vel max 0x03ff)
                                                         //i afegim la direccion amb una mascara or

    sendReciPacket(bID, bParameterLength, bInstruction, Parametros); //cridem la funcio que envia la trama per definir la velocitat i sentit

}

void move(uint16_t speed1, uint16_t speed2, byte bID1, byte bDir1, byte bID2,
          byte bDir2)
{

    setMotorSpeedDir(speed1, bID1, bDir1); //movem el motor dret en la direccion i sentit donats
    setMotorSpeedDir(speed2, bID2, bDir2); //movem el motor esq en la direccion i sentit donats

}

void endavant(uint16_t speed)
{

    byte bID1 = MOTOR_DRET; //adre�em el motor dret
    byte bID2 = MOTOR_ESQ; //adre�em el motor esq
    byte bDir1 = 0x01; //direccio horaria (CW) pel motor
    byte bDir2 = 0x00; //direccio antihoraria (CCW) pel motor
    move(speed, speed, bID1, bDir1, bID2, bDir2); //movem cap a endavant amb la velocitat pasada

}

void endarrere(uint16_t speed)
{

    byte bID1 = MOTOR_DRET; //adre�em el motor dret
    byte bID2 = MOTOR_ESQ; //adre�em el motor esq
    byte bDir1 = 0x00; //direccio antihoraria (CCW) pel motor
    byte bDir2 = 0x01; //direccio horaria (CW) pel motor
    move(speed, speed, bID1, bDir1, bID2, bDir2); //movem cap a endarrere amb la velocitat pasada

}

void movRight(uint16_t speedMain, uint16_t speed)
{
    byte bID1 = MOTOR_DRET; //adre�em el motor dret
    byte bID2 = MOTOR_ESQ; //adre�em el motor esq
    byte bDir1 = 0x01; //direccio antihoraria (CCW) pel motor  //1
    byte bDir2 = 0x00; //direccio antihoraria (CCW) pel motor  //0
    move(speed, speedMain, bID1, bDir1, bID2, bDir2);
}

void movLeft(uint16_t speedMain, uint16_t speed)
{

    byte bID1 = MOTOR_DRET; //adre�em el motor dret
    byte bID2 = MOTOR_ESQ; //adre�em el motor esq
    byte bDir1 = 0x01; //direccio horaria (CW) pel motor  //1
    byte bDir2 = 0x00; //direccio horaria (CW) pel motor  //0
    move(speedMain, speed, bID1, bDir1, bID2, bDir2);
}

void closedMovRight(uint16_t speed)
{
    movRight(speed, 0); //movem cap a la dreta amb la velocitat pasada
    //la roda iterna a vel 0 per tenir el gir tancat

}

void closedMovLeft(uint16_t speed)
{
    movLeft(speed, 0); //movem cap a l'esquerra amb la velocitat pasada
    //la roda iterna a vel 0 per tenir el gir tancat
}

void rotateRight(uint16_t speed)
{
    byte bID1 = MOTOR_DRET; //adre�em el motor dret
    byte bID2 = MOTOR_ESQ; //adre�em el motor esq
    byte bDir1 = 0x00; //direccio antihoraria (CCW) pel motor
    byte bDir2 = 0x00; //direccio antihoraria (CCW) pel motor
    move(speed, speed, bID1, bDir1, bID2, bDir2);
}

void rotateLeft(uint16_t speed)
{
    byte bID1 = MOTOR_DRET; //adre�em el motor dret
    byte bID2 = MOTOR_ESQ; //adre�em el motor esq
    byte bDir1 = 0x01; //direccio horaria (CW) pel motor
    byte bDir2 = 0x01; //direccio horaria (CW) pel motor
    move(speed, speed, bID1, bDir1, bID2, bDir2);
}

DistData readDist(void)
{

    DistData ret;
    RxReturn status;

    byte bID = SENSOR; //Llegim el sensor
    byte bParameterLength = 2; //L'adre�a d'on volem llegir i el nombre de bytes consecutius a llegir
    byte bInstruction = READ_DATA; //READ DATA
    byte Parametros[16];
    Parametros[0] = 0x1A; //Les adre�es dels sensors IR del AX-S1 son 0x1A-0x1C
    Parametros[1] = 0x03; //Volem llegir els 3 sensors de cop

    status = sendReciPacket(bID, bParameterLength, bInstruction, Parametros); //enviem la trama per llegir els valors dels tres sensors IR

    //asignem els valors dels sensors IR llegits a la struct a retornar amb ells
    ret.left = status.StatusPacket[5];
    ret.center = status.StatusPacket[6];
    ret.right = status.StatusPacket[7];

    return ret;
}

void setSoundDetector(void)
{
    byte bID = SENSOR; //Llegim el sensor
    byte bParameterLength = 2; //L'adre�a d'on volem llegir i el nombre de bytes consecutius a llegir
    byte bInstruction = WRITE_DATA; //READ DATA
    byte Parametros[16];
    Parametros[0] = 0x24; //Les adre�es del registre de SO
    Parametros[1] = 0x00; //Volem llegir nom�s aquest registre

    sendReciPacket(bID, bParameterLength, bInstruction, Parametros);

}

byte newSoundDetected(void)
{
    static volatile byte soundDetections = 0;

    RxReturn status;

    byte bID = SENSOR; //Llegim el sensor
    byte bParameterLength = 2; //L'adre�a d'on volem llegir i el nombre de bytes consecutius a llegir
    byte bInstruction = READ_DATA; //READ DATA
    byte Parametros[16];
    Parametros[0] = 0x24; //Les adre�es del registre de SO
    Parametros[1] = 0x01; //Volem llegir nom�s aquest registre

    status = sendReciPacket(bID, bParameterLength, bInstruction, Parametros);

    if (status.StatusPacket[5] > 230) //Si el pic m�xim de so detecta supera 230
    {
        soundDetections = 1;
        return 1 || soundDetections; //true per part del nou so o si ja n'hi ha
    }
    else
    {
        return 0 || soundDetections; //true per part del nou so o si ja n'hi ha
    }

}

void enableMovIfSound(void)
{
    //Si hi ha hagut un nou so configurem el mode continu i activem el torque
    if (newSoundDetected())
    {
        configurar_CONT_MODE();
        enableTorque();
    }
}

void setBuzzerTime(byte time)
{

    byte bID = SENSOR; //Llegim el sensor
    byte bParameterLength = 2; //L'adre�a d'on volem escriure i el valor a posar-hi
    byte bInstruction = WRITE_DATA; //WRITE DATA
    byte Parametros[16];
    Parametros[0] = 0x29; //La adre�a del Buzzer Time
    Parametros[1] = time; //Volem escriure el nou temps

    sendReciPacket(bID, bParameterLength, bInstruction, Parametros); //enviem la trama per llegir els valors dels tres sensors IR

}

void setBuzzerNote(byte note)
{
    byte bID = SENSOR; //Llegim el sensor
    byte bParameterLength = 2; //L'adre�a d'on volem escriure i el valor a posar-hi
    byte bInstruction = WRITE_DATA; //WRITE DATA
    byte Parametros[16];
    Parametros[0] = 0x28; //La adre�a del buzzer note
    Parametros[1] = note; //La nova nota a posar-hi

    sendReciPacket(bID, bParameterLength, bInstruction, Parametros); //enviem la trama per llegir els valors dels tres sensors IR

}

void delay_t(uint32_t temps)
{
    volatile uint32_t i;

    //Delay temporal per proves
    for (i = 0; i < temps; i++)
    {
        ;
    }

}

void TA1_0_IRQHandler(void)
{

    TA1CCTL0 &= ~TIMER_A_CCTLN_CCIFG; //Clear interrupt flag

    TimeOutCnt++; //Sumem 1 al nombre de temps pasat en la base de temps definida per al TA1

}

void stopMotors(void)
{
    byte bID1 = MOTOR_DRET; //adre�em el motor dret
    byte bID2 = MOTOR_ESQ; //adre�em el motor esq
    byte bDir1 = 0x01; //direccio antihoraria (CCW) pel motor encara que es irrellevant al ser la velocitat 0
    byte bDir2 = 0x00; //direccio antihoraria (CCW) pel motor encara que es irrellevant al ser la velocitat 0
    move(0, 0, bID1, bDir1, bID2, bDir2); //posem la vel a 0 als dos motors
}

