#include <msp432p401r.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#include <time.h>

#include "lib_PAE.h"
#include "desplacamentRobot.h"

#define JS_POS_U 4
#define JS_POS_D 5
#define JS_POS_R 5
#define JS_POS_L 7
#define JS_INT_U 0x0A
#define JS_INT_D 0x0C
#define JS_INT_R 0x0C
#define JS_INT_L 0x10
#define JS_BIT_U BIT(JS_POS_U)
#define JS_BIT_D BIT(JS_POS_D)
#define JS_BIT_R BIT(JS_POS_R)
#define JS_BIT_L BIT(JS_POS_L)

#define SPEED 0x1ff //velocitat a la que va el robot

//volatile int TimeCnt = 0;
volatile int RUN_MOTORS = 0;

volatile int CALIBRATE_LEFT = 0;
volatile int CALIBRATE_FRONT = 0;

volatile int STD_DIST = 230; //dist�ncia de seguiment
volatile int SECURE_DIST = 240; //dist�ncia m�xima
volatile int STD_DIST_FRONT = 180; //dist�ncia m�xima forntal
volatile int NO_WAY_STD_DIST = 130; //dist�ncia de sortida carrer�
volatile int NON_FOLLOW_WALL_SECURE_DIST = 50; //dist�ncia de seguimaent paret secundaria
volatile int SET_WALL_DIST = 160; //dist�ncia de seguimaent paret secundaria

volatile int FOLLOW_LEFT = 1; //1 seguir paret esquerra 0 seguir paret dreta

void conf_botones(void)
{

    P5SEL0 &= ~(BIT1 ); //posem en GPIO (00) el P5.1 que correspon al S1
    P5SEL1 &= ~(BIT1 ); //posem en GPIO (00) el P5.1 que correspon al S1
    P3SEL0 &= ~(BIT5 ); //posem en GPIO (00) el P3.5 que correspon al S2
    P3SEL1 &= ~(BIT5 ); //posem en GPIO (00) el P3.5 que correspon al S2

    P5DIR &= ~(BIT1 ); //posem S1 a 0 com a entrada
    P5REN |= (BIT1 ); //Pull-up/pull-down pel pulsador per S1
    P5OUT |= (BIT1 ); //Donat que l'altra costat es GND, volem una pull-up per S1
    P5IE |= (BIT1 ); //Interrupcions activades per S1
    P5IES &= ~(BIT1 ); // amb transicio L->H per S1
    P5IFG = 0; // Netegem les interrupcions anteriors per S1

    P3DIR &= ~(BIT5 ); //posem S2 a 0 com a entrada
    P3REN |= (BIT5 ); //Pull-up/pull-down pel pulsador per S2
    P3OUT |= (BIT5 ); //Donat que l'altra costat es GND, volem una pull-up per S2
    P3IE |= (BIT5 ); //Interrupcions activades per S2
    P3IES &= ~(BIT5 ); // amb transicio L->H per S2
    P3IFG = 0; // Netegem les interrupcions anteriors per S2
}

void init_joystick(void)
{
    //Configuramos el joystick (dreta, esquerra amunt i avall)

    //Joysticks dreta i esquerra D = P4.5 i E = P4.7
    P4SEL0 &= ~(BIT5 + BIT7 );    //Els joystick dreta i esquerra son GPIOs
    P4SEL1 &= ~(BIT5 + BIT7 );    //Els joystick dreta i esquerra son GPIOs

    //Joysticks dreta i esquerra amunt = P5.4 i Avall = P5.5
    P5SEL0 &= ~(BIT4 + BIT5 );    //Els joystick amunt i avall son GPIOs
    P5SEL1 &= ~(BIT4 + BIT5 );    //Els joystick amunt i avall son GPIOs

    //Joysticks dreta i esquerra D = P4.5 i E = P4.7
    P4DIR &= ~(JS_BIT_R + JS_BIT_L);    //Un joystick es una entrada
    P4REN |= (JS_BIT_R + JS_BIT_L);     //Pull-up/pull-down pel joystick
    P4OUT |= (JS_BIT_R + JS_BIT_L); //Donat que l'altra costat es GND, volem una pull-up
    P4IE |= (JS_BIT_R + JS_BIT_L);      //Interrupcions activades
    P4IES &= ~(JS_BIT_R + JS_BIT_L);    // amb transicio L->H
    P4IFG = 0;                  // Netegem les interrupcions anteriors

    //Joysticks dreta i esquerra amunt = P5.4 i Avall = P5.5
    P5DIR &= ~(JS_BIT_U + JS_BIT_D);    //Un joystick es una entrada
    P5REN |= (JS_BIT_U + JS_BIT_D);     //Pull-up/pull-down pel joystick
    P5OUT |= (JS_BIT_U + JS_BIT_D); //Donat que l'altre costat es GND, volem una pull-up
    P5IE |= (JS_BIT_U + JS_BIT_D);      //Interrupcions activades
    P5IES &= ~(JS_BIT_U + JS_BIT_D);    // amb transicio L->H
    P5IFG = 0;                  // Netegem les interrupcions anteriors
}

void init_interrupcionsTA0JS(void)
{

    //Int. port 4 = 38 corresponde al bit 5 del segundo registro ISER1:
    NVIC->ICPR[1] |= 1 << (PORT4_IRQn & 31); //Primero, me aseguro de que no quede ninguna interrupcion residual pendiente para este puerto,
    NVIC->ISER[1] |= 1 << (PORT4_IRQn & 31); //y habilito las interrupciones del puerto

    //Int. port 5 = 39 corresponde al bit 3 del segundo registro ISER1:
    NVIC->ICPR[1] |= 1 << (PORT5_IRQn & 31); //Primero, me aseguro de que no quede ninguna interrupcion residual pendiente para este puerto,
    NVIC->ISER[1] |= 1 << (PORT5_IRQn & 31); //y habilito las interrupciones del puerto

    //Interrupcions botons
    //Int. port 5 = 39 corresponde al bit 5 del segundo registro ISER1:
    NVIC->ICPR[1] |= (BIT5 ); //Primero, me aseguro de que no quede ninguna interrupcion residual pendiente para este puerto,
    NVIC->ISER[1] |= (BIT5 ); //y habilito las interrupciones del puerto
}

void setWall(uint16_t speed)
{
    DistData d = readDist(); //llegim la distancia actual
    //WE FIRST GO STRAIGHT UNTIL WE GET A WALL
    endavant(speed);

    //Si estem ben posicionat amb la paret esquerra comen�em a seguirla
    if (d.left <= SECURE_DIST && d.left >= SET_WALL_DIST)
    {
        followWall(speed); //comen�em a seguir la paret per l'esquerra
    }

    //Si estem ben posicionat amb la paret dreta comen�em a seguirla
    else if (d.right <= SECURE_DIST && d.right >= SET_WALL_DIST)
    {
        FOLLOW_LEFT = 0; //indiquem que la paret s'ha de seguir per la dreta
        followWallRight(speed); //comen�em a seguir la paret per la dreta
    }

    else
    {
        //mentre no tenim una paret a prop de forma frontal
        while ((d.center < STD_DIST_FRONT) && RUN_MOTORS)
        {
            d = readDist(); //llegim la distancia actual
        }

        stopMotors(); //parem els motors
        //Estem m�s a prop de la paret esquerra que de la dreta
        if (d.left >= d.right)
        {

            movRight(speed, speed / 8); //fem un gir avan�ant accentuat a la dreta en tenir un obstacle frontal

            //Tenim la paret propera per la esquerra
            while ((d.left < STD_DIST) && RUN_MOTORS)
            {
                d = readDist(); //llegim la distancia actual

            }

        }
        //Estem m�s a prop de la paret dreta que de la esquerra
        else if (d.left < d.right)
        {
            movLeft(speed, speed / 8); //fem un gir avan�ant accentuat a l'esquerra en tenir un obstacle frontal

            //Tenim la paret propera per la dreta
            while ((d.right < STD_DIST) && RUN_MOTORS)
            {
                d = readDist(); //llegim la distancia actual
            }
            FOLLOW_LEFT = 0; //indiquem que la paret s'ha de seguir per la dreta

        }

    }
    stopMotors(); //parem els motors
}

void avoidCorner(uint16_t speed)
{
    DistData d = readDist(); //llegim la distancia actual
    //16
    movRight(speed, speed / 8); //fem un gir avan�ant accentuat a l'esquerra en tenir un obstacle frontal
    //mentre tinguem paret propera frontal o no tinguem a l'esquerra

    while ((d.center >= STD_DIST_FRONT || d.left < STD_DIST) && RUN_MOTORS)
    {
        d = readDist(); //llegim la distancia actual
        //Activa_TimerA0();
        //wait(10); //Delay de 10 ms fins a tornar a llegir els sensors
        //Desactiva_TimerA0();
    }

}

void avoidCornerRight(uint16_t speed)
{
    DistData d = readDist(); //llegim la distancia actual
    movLeft(speed, speed / 8); //fem un gir avan�ant accentuat a la dreta en tenir un obstacle frontal
    //mentre tinguem paret propera frontal o no tinguem a la dreta
    while ((d.center >= STD_DIST_FRONT || d.right < STD_DIST) && RUN_MOTORS)
    {
        d = readDist(); //llegim la distancia actual
        //Activa_TimerA0();
        //wait(10);  //Delay de 10 ms fins a tornar a llegir els sensors
        //Desactiva_TimerA0();
    }
}

void noWayRight(uint16_t speed)
{
    DistData d = readDist(); //llegim la distancia actual
    char info[] = "Sense cam�";
    halLcdPrintLine(info, 5, INVERT_TEXT); //imprimim que estem sense sortida

    setBuzzerTime(10);
    setBuzzerNote(50); //nota de carrer�
    //Mendre tenim un obstacle en dreta i esquerra llegim la distancia

    while (!(d.left < NO_WAY_STD_DIST || d.right < NO_WAY_STD_DIST)
            && RUN_MOTORS)
    {
        endarrere(speed); //retorcedim
        d = readDist(); //llegim la distancia actual
    }

    //Activa_TimerA0();
    //wait(300);  //Delay de 10 ms fins a tornar a llegir els sensors
    //Desactiva_TimerA0();
    stopMotors(); //parem els motors

    if (d.left < NO_WAY_STD_DIST) //No hi ha obstacle a l'esquerra
    {
        rotateRight(speed); //rotem a la dreta
        //Activa_TimerA0();
        //DESACTIVEM LA CONDICION DEL
        //TIMER PERQUE DEPEN DE LA VELOCITAT I PER TANT DE LA BATERIA
        //Mentre hagi paret a l'esquerra o no hagi al front
        while (((d.right >= NO_WAY_STD_DIST || d.center < STD_DIST_FRONT)
                && RUN_MOTORS)
        /*&& !(TimeOutTA0(1500) && d.center > STD_DIST_FRONT - 40)*/)
        {
            d = readDist(); //llegim la distancia actual
        }
        //DESACTIVEM LA CONDICION DEL
        //TIMER PERQUE DEPEN DE LA VELOCITAT I PER TANT DE LA BATERIA
        //Mentre no hagi a l'esquerra
        while ((!(d.center < STD_DIST_FRONT - 40) && RUN_MOTORS)
        /*&& !(TimeOutTA0(1500) && d.center > STD_DIST_FRONT - 40)*/)
        {
            d = readDist(); //llegim la distancia actual
        }
        //DESACTIVEM EL CAS CANVIAR LA PARET A SEGUIR DE LA DRETA A L'ESQUERRA.
        /*while ((!(d.right < STD_DIST && d.left > SECURE_DIST) && RUN_MOTORS) && !(TimeOutTA0(1500) && d.center>STD_DIST_FRONT-40)) //time out nouevo para caso girar inf //pierdo el derecho y tengo al izq
         {

         d = readDist(); //llegim la distancia actual

         }*/
        //FOLLOW_LEFT=1;
        //Desactiva_TimerA0();
        stopMotors(); //parem els motors

    }
    else if (d.right < NO_WAY_STD_DIST) //No hi ha obstacle a la dreta
    {

        //rotateLeft(speed); //rotem a l'esquerra
        Activa_TimerA0(); //new

        //Mendre no es compleixei que hagi paret a l'esquerra i no a la dreta
        //DESACTIVEM LA CONDICION DEL
        //TIMER PERQUE DEPEN DE LA VELOCITAT I PER TANT DE LA BATERIA
        while ((!(d.left < STD_DIST && d.right > SECURE_DIST) && RUN_MOTORS) /*&& !(TimeOutTA0(1500) && d.center>STD_DIST_FRONT-40)*/)
        {

            d = readDist(); //llegim la distancia actual

        }
        //Desactiva_TimerA0();
        stopMotors(); //parem els motors

    }

}

//case tunel cerrado esquerra
void noWay(uint16_t speed)
{
    DistData d = readDist(); //llegim la distancia actual
    char info[] = "Sense cam�";
    halLcdPrintLine(info, 5, INVERT_TEXT); //imprimim que estem sense sortida

    setBuzzerTime(10);
    setBuzzerNote(50); //nota de carrer�
    //Mendre tenim un obstacle en dreta i esquerra llegim la distancia

    while (!(d.left < NO_WAY_STD_DIST || d.right < NO_WAY_STD_DIST)
            && RUN_MOTORS)
    {
        endarrere(speed); //retorcedim
        d = readDist(); //llegim la distancia actual
    }

    //Activa_TimerA0();
    //wait(300);  //Delay de 10 ms fins a tornar a llegir els sensors
    //Desactiva_TimerA0();
    stopMotors(); //parem els motors

    if (d.left < NO_WAY_STD_DIST) //No hi ha obstacle a l'esquerra
    {

        //rotateLeft(speed); //rotem a l'esquerra
        Activa_TimerA0(); //new

        //Mendre no es compleixei que hagi paret a l'esquerra i no a la dreta
        //DESACTIVEM LA CONDICION DEL
        //TIMER PERQUE DEPEN DE LA VELOCITAT I PER TANT DE LA BATERIA
        while ((!(d.right < STD_DIST && d.left > SECURE_DIST) && RUN_MOTORS) /*&& !(TimeOutTA0(1500) && d.center>STD_DIST_FRONT-40)*/)
        {

            d = readDist(); //llegim la distancia actual

        }
        //Desactiva_TimerA0();//new
        stopMotors(); //parem els motors

    }
    else if (d.right < NO_WAY_STD_DIST) //No hi ha obstacle a la dreta
    {

        rotateRight(speed); //rotem a la dreta
        //Activa_TimerA0();
        //DESACTIVEM LA CONDICION DEL
        //TIMER PERQUE DEPEN DE LA VELOCITAT I PER TANT DE LA BATERIA
        //Mentre hagi paret a l'esquerra o no hagi al front
        while (((d.left >= NO_WAY_STD_DIST || d.center < STD_DIST_FRONT)
                && RUN_MOTORS)
        /*&& !(TimeOutTA0(1500) && d.center > STD_DIST_FRONT - 40)*/)
        {
            d = readDist(); //llegim la distancia actual
        }
        //DESACTIVEM LA CONDICION DEL
        //TIMER PERQUE DEPEN DE LA VELOCITAT I PER TANT DE LA BATERIA
        //Mentre no hagi a l'esquerra
        while ((!(d.center < STD_DIST_FRONT - 40) && RUN_MOTORS)
        /*&& !(TimeOutTA0(1500) && d.center > STD_DIST_FRONT - 40)*/)
        {
            d = readDist(); //llegim la distancia actual
        }
        //DESACTIVEM EL CAS CANVIAR LA PARET A SEGUIR DE LA DRETA A L'ESQUERRA.
        /*while ((!(d.left < STD_DIST && d.right > SECURE_DIST) && RUN_MOTORS) && !(TimeOutTA0(1500) && d.center>STD_DIST_FRONT-40)) //time out nouevo para caso girar inf //pierdo el derecho y tengo al izq
         {

         d = readDist(); //llegim la distancia actual

         }*/
        //FOLLOW_LEFT=0;
        //Desactiva_TimerA0();
        stopMotors(); //parem els motors

    }

}

void followWallRight(uint16_t speed)
{
    DistData d = readDist(); //llegim la distancia actual
    //No tenim un obstacle forntal i ni res a la dreta i ens desviem a l'esquerra
    if (d.right > SECURE_DIST && d.center < STD_DIST_FRONT
            && d.left < NON_FOLLOW_WALL_SECURE_DIST)
    {

        movLeft(speed, speed / 2); //gir suau a l'esquerra
    }
    //No tenim un obstacle forntal i ni res a la dreta i ens desviem a la dreta
    else if (d.right < STD_DIST && d.center < STD_DIST_FRONT
            && d.left < NON_FOLLOW_WALL_SECURE_DIST/*&& d.left != 0*/)
    {
        //Hem perdut la paret (dist es 0)
        if (d.right == 0)  //loopea early
        {
            Activa_TimerA0();
            wait(10);         //esperem 10 ms
            Desactiva_TimerA0();

            rotateRight(900); //rotem a la dreta per corregir
        }

        movRight(speed, speed / 2); //gir suau a la dreta
    }
    //Tenim paret  endavant i no tenim res a l'esquerra
    else if (d.center > STD_DIST_FRONT && d.left < NON_FOLLOW_WALL_SECURE_DIST)
    {
        avoidCornerRight(speed); //cridem la funci� per gestionar que tenim una canonada tancada
    }
    //Obstacle frontal, a la dreta i esquerra
    else if (d.center > STD_DIST_FRONT && d.left > NON_FOLLOW_WALL_SECURE_DIST
            && d.right > NO_WAY_STD_DIST)
    {
        noWayRight(speed); //cridem la funci� per gestionar que no tenim sortida
    }
    //Obstacle frontal, a la dreta i no  a l'esquerra
    else if (d.center > STD_DIST_FRONT && d.left > NON_FOLLOW_WALL_SECURE_DIST
            && d.right < NO_WAY_STD_DIST)
    { //new cond

        movRight(speed, speed / 2); //gir suau a la dreta

    }
    //Molt proper a la paret dreta i m�s que la esquerra
    else if (d.left > STD_DIST && d.left > d.right) //CASO TUNNEL O INICIO DE SINFIN
    { //new cond

        movRight(speed, speed / 2); //gir suau a la dreta

    }
    //Molt proper a la paret esquerra i m�s que la dreta
    else if (d.right > SECURE_DIST && d.right > d.left) //testear
    {
        movLeft(speed, speed / 2); //gir suau a l'esquerra
    }
    else if (d.right < STD_DIST /*nou*/)
    {

        movRight(speed, speed / 2); //gir suau a la dreta
    }
    else
    {
        endavant(speed); //avan�em
    }

    Activa_TimerA0();
    wait(10); //Delay de 10 ms fins a tornar a llegir els sensors
    Desactiva_TimerA0();
}

void followWall(uint16_t speed)
{
    DistData d = readDist(); //llegim la distancia actual
    //No tenim un obstacle forntal i ni res a la dreta i ens desviem a l'esquerra
    if (d.left > SECURE_DIST && d.center < STD_DIST_FRONT
            && d.right < NON_FOLLOW_WALL_SECURE_DIST)
    {

        movRight(speed, speed / 2); //gir suau a la dreta
    }
    //No tenim un obstacle forntal i ni res a la dreta i ens desviem a la dreta
    else if (d.left < STD_DIST && d.center < STD_DIST_FRONT
            && d.right < NON_FOLLOW_WALL_SECURE_DIST/*&& d.left != 0*/)
    {
        //Hem perdut la paret (dist es 0)
        if (d.left == 0)  //loopea early
        {
            Activa_TimerA0();
            wait(10);         //esperem 10 ms
            Desactiva_TimerA0();
            setBuzzerTime(20); //emetem so indicant que s'ha pr�s el valor pel sensor esquerre
            setBuzzerNote(50);
            rotateLeft(600); //rotem a l'esquerra per corregir 600
        }

        movLeft(speed, speed / 2); //gir suau a l'esquerra
    }
    //Tenim paret  endavant i no tenim res a l'esquerra
    else if (d.center > STD_DIST_FRONT && d.right < NON_FOLLOW_WALL_SECURE_DIST)
    {
        avoidCorner(speed); //cridem la funci� per gestionar que tenim una canonada tancada
    }
    //Obstacle frontal, a la dreta i esquerra
    else if (d.center > STD_DIST_FRONT && d.right > NON_FOLLOW_WALL_SECURE_DIST
            && d.left > NO_WAY_STD_DIST)
    {
        noWay(speed); //cridem la funci� per gestionar que no tenim sortida
    }
    //Obstacle frontal, a la dreta i no  a l'esquerra
    else if (d.center > STD_DIST_FRONT && d.right > NON_FOLLOW_WALL_SECURE_DIST
            && d.left < NO_WAY_STD_DIST)
    {

        movLeft(speed, speed / 2); //gir suau a l'esquerra

    }
    //Molt proper a la paret dreta i m�s que la esquerra
    else if (d.right > STD_DIST && d.right > d.left) //CASO TUNNEL O INICIO DE SINFIN
    {

        movLeft(speed, speed / 2); //gir suau a l'esquerra

    }
    //Molt proper a la paret esquerra i m�s que la dreta
    else if (d.left > SECURE_DIST && d.left > d.right) //testear
    {
        movRight(speed, speed / 2); //gir suau a la dreta
    }
    else if (d.left < STD_DIST /*nou*/)
    {

        movLeft(speed, speed / 2); //gir suau a l'esquerra
    }
    else
    {
        endavant(speed); //avan�em
    }

    Activa_TimerA0();
    wait(10); //Delay de 10 ms fins a tornar a llegir els sensors
    Desactiva_TimerA0();
}

void calibrateDist(void)
{
    DistData d = readDist(); //llegim la distancia actual

    //mentre no s'hagi solicitat calibrar i el valor de calibrat no sigui molt petit
    /*while (!CALIBRATE_FRONT || d.center == 0 || d.center < 20) //100
     {
     d = readDist(); //llegim la distancia actual
     }
     STD_DIST_FRONT = d.center;
     setBuzzerTime(20); //emetem so indicant que s'ha pr�s el valor pel sensor frontal
     setBuzzerNote(20);
     */
    //mentre no s'hagi solicitat calibrar i el valor de calibrat no sigui molt petit
    while (!CALIBRATE_LEFT || d.left == 0 || d.left < 20) //100
    {
        d = readDist(); //llegim la distancia actual
    }
    //definim les dist�ncies laterals segons correspon

    SECURE_DIST = d.left;

    STD_DIST_FRONT = SECURE_DIST - 20;
    STD_DIST = SECURE_DIST - 10;
    NO_WAY_STD_DIST = (int) (STD_DIST / 3);
    NON_FOLLOW_WALL_SECURE_DIST = (int) ((STD_DIST * 3) / 9);
    SET_WALL_DIST = (int) ((STD_DIST * 2) / 3);
    setBuzzerTime(20); //emetem so indicant que s'ha pr�s el valor pel sensor esquerre
    setBuzzerNote(50);

    Activa_TimerA0();
    wait(3000); //delay de 3s per no iniciar l'execuci� ambla detecci� del so de lectura del sensor lateral pr�vi
    Desactiva_TimerA0();
    RUN_MOTORS = 0;
    stopMotors();

}

/**
 * main.c
 */
void main(void)
{
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;     // stop watchdog timer

    //Inicializaciones:
    init_ucs_24MHz();
    initLCD();
    halLcdInit();
    //halLcdClearLine(8);

    init_timers(); //configurem els Timers
    init_UART(); //Inicialitzem la eUSCI A2 com a UART
    init_interrupciones(); //Configurar y activar las interrupciones de los recursos (TA1 TA0 y eUSCIA2)

    init_joystick(); //inicializtem el joystick
    conf_botones(); //inicialitzem els botons del boosterpack
    init_interrupcionsTA0JS(); //inicialitzem les interrupcions del joytsick i dels botons del boosterpack

    __enable_interrupts(); //Activem les interrupcions a nivell global

    stopMotors(); //posem la velocitat a 0 per defecte

    char info[] = "Iniciant robot";
    halLcdPrintLine(info, 5, INVERT_TEXT); //imprimim un text per pantalla  conforme s'est� inicialitzant el robot

    uint16_t speed = SPEED; //definim la velocitat

    setSoundDetector(); //posem el so m�xim detectat a 0
    //calibrateDist(); //calibrem les dist�ncies dels sensors
    while (!RUN_MOTORS && !newSoundDetected()) //mentre no  s'ha accionat el joystick cap endavant i no s'ha detectat un so
    {

    }
    RUN_MOTORS = 1; //1 conforme el robot es pot moure

    setBuzzerTime(255); //emetem melodia d'inici
    setBuzzerNote(3);
    configurar_CONT_MODE(); //posem el robot en mode contin�
    enableTorque(); //habilitem el torque
    setWall(speed); //busquem paret i posem el robot de costat

    while (1)
    {
        if (RUN_MOTORS) //si no 'sha indicat que s'han de parar el robot amb el joytstick de sota
        {
            if (FOLLOW_LEFT) // hem de seguir la paret per l'esquerra
                followWall(speed); //seguim la paret per l'esquerra
            else
                followWallRight(speed); //seguim la paret per la dreta
        }
        else
        {
            setBuzzerTime(255); //emetem una melodia de fi
            setBuzzerNote(23);
            stopMotors(); //parem els motors
        }

    }

}

void PORT3_IRQHandler(void)  //S2 --> el robot s'atura
{
    uint8_t flag = P3IV; //guardamos el vector de interrupciones. De paso, al acceder a este vector, se limpia automaticamente.
    P3IE &= ~(BIT5 ); //interrupciones del boton S2 en port 1 desactivadas
    /*
     * Per veure a quin numero del P5IV corresponen a les interrupcions del PORTX5, hem consultat el
     * manual (MSP432P4xx SimpleLink Microcontrollers Technical Reference Manual); a la pagina 695.
     * Obtenim, doncs, que si es produeix una interrupcio en el 3.5 (boto S2) el valor del vector
     * d'interrupcions es 0Ch (12 en decimal).
     */
    switch (flag)
    {
    case 12: //cas S2
        CALIBRATE_FRONT = 1; //indicat que l'usuari ha polsat per calibrar el sensor frontal
        break;
    default:
        break;
    }
    P3IE |= BIT5; //interrupciones del  S2 en port 1 desactivadas
}

void PORT4_IRQHandler(void)
{
    uint8_t flag = P4IV; //guardamos el vector de interrupciones. De paso, al acceder a este vector, se limpia automaticamente.
    P4IE &= ~(JS_BIT_R + JS_BIT_L); //interrupciones de los joystick de derecha e izquierda en port 4 desactivadas

    switch (flag)
    {
    case JS_INT_R: //CAS joystick mogut a la dreta

        if ((SECURE_DIST + 5) < 255)
        {
            SECURE_DIST += 5;
            STD_DIST_FRONT = SECURE_DIST - 20;
            STD_DIST = SECURE_DIST - 10;
            NO_WAY_STD_DIST = (int) (STD_DIST / 3);
            NON_FOLLOW_WALL_SECURE_DIST = (int) ((STD_DIST * 3) / 9);
            SET_WALL_DIST = (int) ((STD_DIST * 2) / 3);
        }

        break;
    case JS_INT_L:   //CAS joystick mogut cap a l'esquerra

        if ((SECURE_DIST - 5) > 0)
        {
            SECURE_DIST -= 5;
            STD_DIST_FRONT = SECURE_DIST - 20;
            STD_DIST = SECURE_DIST - 10;
            NO_WAY_STD_DIST = (int) (STD_DIST / 3);
            NON_FOLLOW_WALL_SECURE_DIST = (int) ((STD_DIST * 3) / 9);
            SET_WALL_DIST = (int) ((STD_DIST * 2) / 3);
        }

        break;
    default:
        break;
    }

    P4IE |= (JS_BIT_R + JS_BIT_L); //interrupciones de los joystick de derecha e izquierda en port 4 reactivadas
}

void PORT5_IRQHandler(void)
{
    uint8_t flag = P5IV; //guardamos el vector de interrupciones. De paso, al acceder a este vector, se limpia automaticamente.
    P5IE &= ~(JS_BIT_U + JS_BIT_D + 0x04); //interrupciones de los joystick de arriba y abajo y S1 en port 5 desactivadas

    switch (flag)
    {
    case 0x04: //cas S1
        CALIBRATE_LEFT = 1; //indicat que l'usuari ha polsat per calibrar el sensor esquerre
        break;
    case JS_INT_U: //CAS joystick mogut adalt
        RUN_MOTORS = 1; //indicat que l'usuari ha polsat per comen�ar a  moure el robot
        break;
    case JS_INT_D: //CAS joystick mogut avall
        RUN_MOTORS = 0; //indicat que l'usuari ha polsat per comen�ar a  moure el robot
        break;
    default:
        break;
    }

    P5IE |= (JS_BIT_U + JS_BIT_D + 0x04); //interrupciones de los joystick de arriba y abajo y S1 en port 5 reactivadas
}
